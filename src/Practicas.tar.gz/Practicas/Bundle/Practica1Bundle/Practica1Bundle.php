<?php

namespace Practicas\Bundle\Practica1Bundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class Practica1Bundle extends Bundle
{
}
